import React from 'react';

const About = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-8">About Me</h1>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Bio</h2>
        <p className="text-gray-700">
          Hello! I'm [Your Name], a passionate developer with experience in building web applications using modern technologies. I love coding and solving problems through efficient and scalable solutions. When I'm not coding, you can find me exploring new technologies, reading books, or enjoying outdoor activities.
        </p>
      </div>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Skills</h2>
        <ul className="list-disc pl-6 text-gray-700">
          <li>JavaScript</li>
          <li>React</li>
          <li>Node.js</li>
          <li>Express</li>
          <li>MongoDB</li>
          <li>HTML & CSS</li>
          <li>Git & GitHub</li>
          <li>Tailwind CSS</li>
        </ul>
      </div>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Experience</h2>
        <div className="space-y-4">
          <div>
            <h3 className="text-xl font-semibold">Frontend Developer at XYZ Company</h3>
            <p className="text-gray-700 italic">Jan 2021 - Present</p>
            <p className="text-gray-700">
              Working on building and maintaining responsive web applications using React and Tailwind CSS. Collaborated with the design team to create user-friendly interfaces and improved the performance of web applications by optimizing code and assets.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold">Full Stack Developer at ABC Solutions</h3>
            <p className="text-gray-700 italic">Jun 2019 - Dec 2020</p>
            <p className="text-gray-700">
              Developed and maintained full-stack applications using Node.js, Express, and MongoDB. Implemented RESTful APIs and worked on integrating third-party services. Enhanced the security and scalability of applications through best practices and regular code reviews.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Education</h2>
        <div className="space-y-4">
          <div>
            <h3 className="text-xl font-semibold">Bachelor of Science in Computer Science</h3>
            <p className="text-gray-700 italic">University of Technology, 2015 - 2019</p>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">Hobbies</h2>
        <p className="text-gray-700">
          In my free time, I enjoy hiking, reading, playing video games, and exploring new cuisines. I'm also an avid traveler and love experiencing different cultures and landscapes.
        </p>
      </div>
    </div>
  );
}

export default About;
