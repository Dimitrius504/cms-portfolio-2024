import React from 'react'

const BlogPost = () => {
  return (
	<div>BlogPost</div>
  )
}

export default BlogPost