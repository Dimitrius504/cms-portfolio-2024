import React from 'react';
import HeroContents from '../components/Home/HeroContents';
import Cards from '../components/Home/Cards';

const Home = () => {
  return (
	<div className=''>
     <HeroContents title='Dimitrius McKinnon' subtitle='Welcome To My Portfolio' bg='bg-indigo-700'/>
    <section>
      <Cards  />
    </section>
	</div>
  )
}

export default Home