import React from "react";
import { NavLink } from "react-router-dom";

const NavLinks = () => {
  return (
    <div>
      <ul className="flex flex-1 items-center justify-center md:items-stretch md:justify-start lg:gap-x-12">
        <li className="">
          <NavLink to="/skills">Skills</NavLink>
        </li>
        <li>
          <NavLink to="/about">About</NavLink>
        </li>
        <li>
          <NavLink to="/blog">Blog</NavLink>
        </li>
        <li>
          <NavLink to="/contact">Contact</NavLink>
        </li>
        <li>
          <NavLink to="/projects">Projects</NavLink>
        </li>
        <li>
          <NavLink to="/resume">Resume</NavLink>
        </li>
      </ul>
    </div>
  );
};

export default NavLinks;
