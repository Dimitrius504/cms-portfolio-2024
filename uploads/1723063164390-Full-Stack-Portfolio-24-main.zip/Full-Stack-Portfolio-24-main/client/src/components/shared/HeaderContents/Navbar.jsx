import React from "react";
import NavLinks from "./NavLinks";
import { Link } from "react-router-dom";
import { VscAccount } from "react-icons/vsc";

const Navbar = () => {
  return (
    <nav className="flex items-center justify-between p-6 bg-blue-800">
      <div className="flex items-center w-1/4">
        <Link to="/">
          <text
            x="50%"
            y="50%"
            dominantBaseline="middle"
            textAnchor="middle"
            fontFamily="Arial, sans-serif"
            fontSize="30"
            fill="#FFFFFF"
          >
            DM
          </text>
        </Link>
      </div>
      <div className="flex-grow flex justify-center">
        <NavLinks />
      </div>
      <div className="flex items-center w-1/4 justify-end">
        <Link to="/account">
          <VscAccount size={40} fill="white" />
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
