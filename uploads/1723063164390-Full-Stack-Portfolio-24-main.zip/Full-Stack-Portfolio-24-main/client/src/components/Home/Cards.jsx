import React from "react";
import Card from './Card';
import { Link } from "react-router-dom";

const Cards = () => {
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-lg">
          <Card className='flex'>
            <h2 className="text-2xl font-bold flex justify-center">Status</h2>
            <h3 className="text-2xl">
              Employed
            </h3>
			<p className="mt-4 mb-4">
              Working At Canadian Cutters
            </p>
			<p className="font-bold mt-4 mb-4">
				Employed Since: 02/10/2999
			</p>
            <Link
              to="/blog"
              className="inline-block bg-black text-white rounded-lg px-4 py-2 hover:bg-gray-700"
            >
              See Blog Content
            </Link>
          </Card>
          <Card className='flex'>
            <h2 className="text-2xl font-bold flex justify-center">Testimonials</h2>
			<h3 className="text-2xl">Poops McGee</h3>
            <p className="mt-2 mb-4">
              Dimitrius is poop and stink and gay and stupid and poopy probably
            </p>
            <Link
              to="/resume"
              className="inline-block bg-indigo-500 text-white rounded-lg px-4 py-2 hover:bg-indigo-600"
            >
              See Resume
            </Link>
          </Card>
        </div>
    </>
  );
};

export default Cards;
