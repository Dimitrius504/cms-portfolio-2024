import React, { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Component Imports
import Header from "./components/shared/HeaderContents/Header";
import Footer from "./components/shared/FooterContents/Footer";

// Lazy Page Imports
const ProjectsTestPage = lazy(() => import('./pages/ProjectsTest'))
const SkillsTestPage = lazy(() => import('./pages/SkillsTest'));
const Homepage = lazy(() => import("./pages/Home"));
const Skillspage = lazy(() => import("./pages/Skills"));
const Aboutpage = lazy(() => import("./pages/About"));
const Blogpage = lazy(() => import("./pages/Blog"));
const Contactpage = lazy(() => import("./pages/Contact"));
const Projectspage = lazy(() => import("./pages/Projects"));
const Resumepage = lazy(() => import("./pages/Resume"));
const BlogPostpage = lazy(() => import("./pages/BlogPost"));
const Accountpage = lazy(() => import("./pages/Account"));
const AdminCategorySubmit = lazy(() => import('../admin/pages/SubmitCategories'));
const AdminSkillSubmit = lazy(() => import('../admin/pages/SubmitSkills'));
const AdminSingleSkillPage = lazy(() => import('../admin/pages/singleSkillTemplate/Skill'));
const AdminProjectSubmit = lazy(() => import('../admin/pages/SubmitProject'));
const AdminSingleProjectPage = lazy(() => import('../admin/pages/singleProjectTemplate/Project'));


const App = () => {
  return (
    <div className="flex flex-col h-screen">
      <BrowserRouter>
        <Header />
        <main className="flex-grow">
          <Suspense fallback={""}>
            <Routes>
              <Route path="/" element={<Homepage />} />
              <Route path="/skills" element={<Skillspage />} />
              <Route path="/about" element={<Aboutpage />} />
              <Route path="/blog" element={<Blogpage />} />
              <Route path="/blog/post/:_id" element={<BlogPostpage />} />
              <Route path="/contact" element={<Contactpage />} />
              <Route path="/projects" element={<Projectspage />} />
              <Route path="/resume" element={<Resumepage />} />
              <Route path="/account" element={<Accountpage />} />
              <Route path="/admin/categories" element={<AdminCategorySubmit />} />
              <Route path="/admin/skills" element={<AdminSkillSubmit  />} />
              <Route path="/admin/skill/:id" element={<AdminSingleSkillPage  />} />
              <Route path="/admin/projects" element={<AdminProjectSubmit  />} />
              <Route path="/admin/project/:id" element={<AdminSingleProjectPage  />} />
              <Route path='/skilltest' element={<SkillsTestPage />} />
              <Route path="/projectstest" element={<ProjectsTestPage  />} />
            </Routes>
          </Suspense>
        </main>
        <Footer />
      </BrowserRouter>
    </div>
  );
};

export default App;
