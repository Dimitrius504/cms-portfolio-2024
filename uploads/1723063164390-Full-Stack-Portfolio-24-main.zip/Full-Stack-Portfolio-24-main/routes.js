import express from "express";
import skillsRouter from './server/routes/skills.js'
import categoriesRouter from './server/routes/categories.js'
import projectsRouter from './server/routes/projects.js'

const router = express.Router();

router.use('/skills', skillsRouter)
router.use('/categories', categoriesRouter)
router.use('/projects', projectsRouter)

export default router;
