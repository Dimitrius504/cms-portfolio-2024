// routes/projects.js

import express from "express";
import Project from "../models/ProjectSchema.js";
import Skill from "../models/SkillSchema.js";

const router = express.Router();

// GET all projects
router.get("/", async (req, res) => {
  try {
    const projects = await Project.find({}).populate("skills", "name");
    res.json(projects);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// POST a new project
// Example of validation middleware in Express.js
router.post("/", async (req, res) => {
  const { title, description, githubLink, date, skills } = req.body;
  if (!title || !description || !githubLink || !date || !skills) {
    return res.status(400).json({ message: "All fields are required." });
  }

  try {
    const project = new Project({
      title,
      description,
      githubLink,
      liveLink: req.body.liveLink || "", // Optional field
      date,
      skills,
    });

    const newProject = await project.save();
    res.status(201).json(newProject);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const project = await Project.findById(req.params.id)
	.populate('skills', 'name')
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    res.json(project);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.patch("/:id", async (req, res) => {
	try {
	  const { title, description, githubLink, liveLink, date, skills } = req.body;
	  const project = await Project.findById(req.params.id);
  
	  if (!project) {
		return res.status(404).json({ message: "Project not found" });
	  }
  
	  // Update project fields
	  project.title = title;
	  project.description = description;
	  project.githubLink = githubLink;
	  project.liveLink = liveLink || "";
	  project.date = new Date(date); // Convert date string to Date object
  
	  // Update skills
	  if (skills && Array.isArray(skills)) {
		project.skills = skills; // Assuming skills is an array of skill IDs
	  }
  
	  const updatedProject = await project.save();
	  res.json(updatedProject);
	} catch (error) {
	  res.status(400).json({ message: error.message });
	}
  });

router.delete("/:id", async (req, res) => {
	try {
	  const project = await Project.findById(req.params.id);
	  if (!project) {
		return res.status(404).json({ message: "Project not found" });
	  }
  
	  await Project.deleteOne({ _id: req.params.id });
	  res.json({ message: "Project deleted successfully" });
	} catch (error) {
	  res.status(500).json({ message: error.message });
	}
  });
  


export default router;
