import express from "express";
import Category from "../models/CategorySchema.js";
import mongoose from "mongoose";

const router = express.Router();

// Get all skills
router.get("/", async (req, res) => {
  try {
    const categories = await Category.find({}).populate('skills', 'name rating icon');
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Create a skill
router.post("/", async (req, res) => {
  const category = new Category({
    name: req.body.name,
    skills: req.body.skills,
  });
  try {
    const newCategory = await category.save();
    res.status(201).json(newCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get a specific skill
router.get("/:id", async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);
    if (!category) return res.status(404).json({ message: "Skill not found" });
    res.json(category);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
// Edit a category
router.patch("/:id", async (req, res) => {
  try {
    const categoryId = req.params.id;
    const updatedFields = {};

    if (req.body.name) updatedFields.name = req.body.name;
    if (req.body.skills) updatedFields.skills = req.body.skills;

    const updatedCategory = await Category.findByIdAndUpdate(
      categoryId,
      { $set: updatedFields },
      { new: true } // Return the updated document
    );

    if (!updatedCategory) {
      return res.status(404).json({ message: "Category not found" });
    }

    res.json(updatedCategory);
  } catch (error) {
    console.error("Error updating category:", error);
    res.status(400).json({ message: error.message });
  }
});

// Delete a skill
router.delete("/:id", async (req, res) => {
  try {
    const categoryId = req.params.id;
    const deletedCategory = await Category.findByIdAndDelete(categoryId);

    if (!deletedCategory) {
      return res.status(404).json({ message: "Category not found" });
    }

    res.json({ message: "Category deleted successfully" });
  } catch (error) {
    console.error("Error deleting category:", error);
    res.status(500).json({ message: error.message });
  }
});

export default router;
