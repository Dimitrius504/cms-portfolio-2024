import express from "express";
import Skill from "../models/SkillSchema.js";
import Category from "../models/CategorySchema.js";
import Project from "../models/ProjectSchema.js";
import mongoose from "mongoose";

const router = express.Router();

// Get skills, optionally filtered by parentSkillCategory
router.get("/", async (req, res) => {
  try {
    const { categoryId } = req.query;
    let filter = {};

    if (categoryId) {
      filter.parentSkillCategory = categoryId;
    }

    const skills = await Skill.find(filter)
      .populate("parentSkillCategory", "name")
      .populate({
        path: "projects",
        select: "title",
        model: "Project",
      });

    console.log("Fetched skills:", skills); // Add this line for logging

    res.json(skills);
  } catch (error) {
    console.error("Error fetching skills:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// Get a specific skill by ID
router.get("/:id", async (req, res) => {
  try {
    const skill = await Skill.findById(req.params.id).populate(
      "parentSkillCategory",
      "name"
    ); // Populate parentSkillCategory with its name

    if (!skill) {
      return res.status(404).json({ message: "Skill not found" });
    }

    // Find projects associated with this skill ID
    const projects = await Project.find({ skills: req.params.id }).select(
      "title"
    );

    res.json({
      skill,
      projects,
    });
  } catch (error) {
    console.error("Error fetching skill and associated projects:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// Create a skill
router.post("/", async (req, res) => {
  const skill = new Skill({
    name: req.body.name,
    parentSkillCategory: req.body.parentSkillCategory,
    rating: req.body.rating,
    icon: req.body.icon,
  });
  try {
    const newSkill = await skill.save();
    res.status(201).json(newSkill);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Edit a skill
router.patch("/:id", async (req, res) => {
  try {
    const skill = await Skill.findById(req.params.id);
    if (!skill) return res.status(404).json({ message: "Skill not found" });

    if (req.body.name != null) skill.name = req.body.name;
    if (req.body.parentSkillCategory != null)
      skill.parentSkillCategory = req.body.parentSkillCategory;
    if (req.body.rating != null) skill.rating = req.body.rating;
    if (req.body.icon != null) skill.icon = req.body.icon;

    const updatedSkill = await skill.save();
    res.json(updatedSkill);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete a skill
router.delete("/:id", async (req, res) => {
  try {
    const skillId = req.params.id;

    // Find all projects that have this skill in their skills array
    const projects = await Project.find({ skills: skillId });

    // Remove the skill from each project's skills array
    for (let project of projects) {
      project.skills = project.skills.filter(
        (skill) => skill.toString() !== skillId
      );
      await project.save();
    }

    // Delete the skill itself
    const skill = await Skill.findByIdAndDelete(skillId);
    if (!skill) {
      return res.status(404).json({ message: "Skill not found" });
    }

    res.json({ message: "Skill deleted successfully" });
  } catch (error) {
    console.error("Error deleting skill:", error);
    res.status(500).json({ message: error.message });
  }
});

export default router;
