import path from 'path';
import express from 'express';
import apiRoutes from '../routes.js'
import { fileURLToPath } from 'url';
import MongooseProvider from './providers/mongooseProvider.js';

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.urlencoded({extended: true}));

MongooseProvider();

// Define routes
app.use('/api', apiRoutes);

// Serve static files from the React frontend
app.use(express.static(path.join(__dirname, '../client/build')));

// Handle any other routes with the React frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
